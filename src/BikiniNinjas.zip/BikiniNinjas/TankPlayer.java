package BikiniNinjas;

import battlecode.common.GameActionException;
import battlecode.common.RobotController;

public class TankPlayer extends AbstractPlayer {

    public TankPlayer(RobotController rc) throws GameActionException {
        super(rc);
    }

    @Override
    protected void initialize() throws GameActionException {

    }

    @Override
    protected void step() throws GameActionException {

    }
}
