package BikiniNinjas;

public class Tuple<X, Y> {
    public X item1;
    public Y item2;

    public Tuple(X item1, Y item2) {
        this.item1 = item1;
        this.item2 = item2;
    }
}

